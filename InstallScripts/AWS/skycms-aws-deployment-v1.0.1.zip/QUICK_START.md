# SkyCMS AWS Deployment - Quick Start

## Prerequisites

1. **AWS CLI** - Install from https://aws.amazon.com/cli/
   ```powershell
   aws --version
   ```

2. **Node.js 18+** - Install from https://nodejs.org/
   ```powershell
   node --version
   npm --version
   ```

3. **Docker** - Your Docker image should be available in Docker Hub or ECR
   - Default: toiyabe/sky-editor:latest

4. **AWS Credentials** - Configure with appropriate permissions
   ```powershell
   aws configure
   ```

## Installation Steps

1. **Extract this package** to a directory of your choice

2. **Navigate to the directory**
   ```powershell
   cd skycms-aws-deployment
   ```

3. **Run the deployment script**
   ```powershell
   .\cdk-deploy.ps1
   ```

4. **Follow the interactive prompts** to configure:
   - AWS Region (default: us-east-1)
   - Docker image name
   - ECS task count
   - Database name
   - Stack name
   - Whether to deploy Publisher (S3 + CloudFront)

## What Gets Deployed

- **VPC** with public/private subnets
- **RDS MySQL** database (db.t3.micro)
- **ECS Fargate** cluster with your Docker container
- **Application Load Balancer**
- **CloudFront** distribution with auto-generated TLS certificate
- **S3 bucket** (if Publisher enabled)
- **CloudWatch** log groups

## Estimated Costs

- RDS MySQL (db.t3.micro): ~\-20/month
- ECS Fargate (1 task): ~\-20/month
- ALB: ~\-20/month
- CloudFront: Pay-as-you-go (minimal for low traffic)
- Total: ~\-70/month for minimal deployment

## Cleanup

To remove all resources:
```powershell
.\cdk-destroy.ps1
```

## Troubleshooting

- Ensure AWS credentials are configured correctly
- Check that your Docker image is accessible
- Review CloudWatch logs for application issues
- Verify security group rules if you can't connect

## Support

For issues or questions, visit: https://github.com/CWALabs/SkyCMS/issues
